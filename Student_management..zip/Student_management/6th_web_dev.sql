-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2024 at 06:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `6th_web_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(250) NOT NULL,
  `course_id` int(250) NOT NULL,
  `course_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_id`, `course_name`) VALUES
(1, 24667, 'Web Design & Development'),
(2, 23342, 'Database Management'),
(3, 35355, 'Operating System');

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE `enroll` (
  `id` int(123) NOT NULL,
  `email` varchar(250) NOT NULL,
  `course_id` int(123) NOT NULL,
  `course_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `enroll`
--

INSERT INTO `enroll` (`id`, `email`, `course_id`, `course_name`) VALUES
(6, '', 24667, 'Web Design & Development'),
(7, '', 24667, 'Web Design & Development'),
(8, 'p@gmail.com', 24667, 'Web Design & Development'),
(9, 'p@gmail.com', 23342, 'Database Management'),
(10, 'p@gmail.com', 35355, 'Operating System'),
(11, 'p@gmail.com', 35355, 'Operating System'),
(12, 'p@gmail.com', 24667, 'Web Design & Development'),
(13, 'p@gmail.com', 23342, 'Database Management'),
(14, 'p@gmail.com', 24667, 'Web Design & Development'),
(15, 'p@gmail.com', 35355, 'Operating System');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `id` int(250) NOT NULL,
  `uname` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `pwd` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `uname`, `dob`, `address`, `email`, `pwd`) VALUES
(1, 'RamKrishna', '2024-10-04', 'Ctg', ' ram@gmail.com', '123'),
(3, 'A', '2024-10-05', 'Anawara', ' a@gmail.com', '123'),
(4, 'P', '22-10-1999', 'CTG', 'p@gmail.com', '123'),
(5, 'Joyita Das Gupta', '1999-06-06', 'Ctg', ' joyi@gmail.com', '123'),
(6, 'Asu', '2024-10-03', 'Ctg', ' asu@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enroll`
--
ALTER TABLE `enroll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `enroll`
--
ALTER TABLE `enroll`
  MODIFY `id` int(123) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
