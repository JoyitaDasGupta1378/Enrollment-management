<?php
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit;
}

                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "6th_web_dev";  // Replace with your actual database name

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch courses from the courses table
                    $sql = "SELECT course_id, course_name FROM courses";
                    $result = $conn->query($sql);

                    // Check if there are any success messages
                    $success_message = isset($_SESSION['success_message']) ? $_SESSION['success_message'] : null;

                        // Clear success messages after displaying them
                        unset($_SESSION['success_messages']);




?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Enrollment</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">

    <h2 class="mb-4">Course Enrollment</h2>

    <?php if ($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>




    
        <form action="enroll.php" method="post">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Course ID</th>
                        <th>Course Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    // Display each course in a table row
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td><input type="checkbox" name="course_ids[]" value="' . $row['course_id'] . '"></td>';
                            echo '<td>' . $row['course_id'] . '</td>';
                            echo '<td>' . $row['course_name'] . '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="3">No courses available.</td></tr>';
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
