<?php
 session_start();

 $conn=mysqli_connect('localhost','root','','6th_web_dev');
 $uname= $_POST['uname'];
 $dob=$_POST['dob'];
 $address=$_POST['address'];
 $email=$_POST['email'];
 $pwd=$_POST['pwd'];

$sql="INSERT INTO reg (uname,dob,address,email,pwd) VALUES ('$uname','$dob','$address',' $email','$pwd') ";
$check= mysqli_query($conn,$sql);
if ($check)
{
    $_SESSION['status']="You are a successfully registered!";
    header('location:reg.php');

}
else {
    echo "Failed";
}


?>