<?php
// Database connection
$servername = "localhost"; // Your server name
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "6th_web_dev"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if any checkboxes are selected
    if (isset($_POST['selected_ids'])) {
        $selected_ids = $_POST['selected_ids'];

        // Prepare the SQL statement to insert the selected rows
        $stmt = $conn->prepare("INSERT INTO enroll (uname,course_id,course_name) VALUES (?)");

        // Check if the statement was prepared successfully
        if ($stmt) {
            foreach ($selected_ids as $id) {
                $stmt->bind_param("i", $id); // Bind the ID as an integer
                $stmt->execute(); // Execute the insert statement
            }
            echo "Records inserted successfully.";
            $stmt->close(); // Close the prepared statement
        } else {
            echo "Error preparing the statement: " . $conn->error;
        }
    } else {
        echo "No users selected.";
    }
}

// Close connection
$conn->close();
?>
