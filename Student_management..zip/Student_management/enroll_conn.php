<?php
// Database connection settings
$host = 'localhost';
$dbname = '6th_web_dev';
$username = 'root'; // Change if you have a different username
$password = ''; // Change if you have a password set

// Establish connection to the database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_rows'])) {
    // Prepare the SQL query for inserting data
    $stmt = $pdo->prepare("INSERT INTO enrollment (course_id, course_name) VALUES (:course_id, :course_name)");

    // Loop through selected rows and insert into the database
    foreach ($_POST['selected_rows'] as $selected) {
        // Assume item names and categories are predefined for this example
        $course_name = "Item " . $selected; // You can customize this
        //$category = "Category A"; // You can customize this or retrieve from a dropdown

        $stmt->bindValue(':course_id', $selected);
        $stmt->bindValue(':course_name', $course_name);
        //$stmt->bindValue(':category', $category);
        $stmt->execute();
    }

    echo "<h4 class='mt-5'>Selected items have been stored in the database.</h4>";
}
?>
