<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// Database connection
$host = 'localhost';
$user = 'root';  // Replace with your MySQL username
$pass = '';      // Replace with your MySQL password
$db = '6th_web_dev'; 

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    // Get user input
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];

    // Query to check if the user exists in the 'users' table based on email and password
    $sql = "SELECT email,pwd FROM reg WHERE email = '$email' AND pwd = '$pwd'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // User exists, set session with email
        $_SESSION['email'] = $email;
        header('Location: index2.php');  // Redirect to course enrollment page
    } else {
        echo "Invalid email or password.";
    }

    // Close connection
    $conn->close();
}
?>





























