<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Registration</title>
    
</head>
<body>
<div class="container mt-4">

<?php
  if(isset($_SESSION['status']))
  {

    ?>
    
      <div class="alert alert-success alert-dismissible">
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        <strong>Success!</strong><?php
         echo $_SESSION['status'];?> 
         <a href="login.php">Back to login</a>
      </div>


    <?php
    unset($_SESSION['status']);
  }
  ?>




  <h2>Registration form</h2>
  <div class="row col-6 ">
  <form action="connection.php" method="POST" >
  <div class="mb-3 mt-3">
      <label for="uname">Username</label>
      <input type="text" class="form-control" id="uname" placeholder="Enter Name" name="uname">
    </div>
    <div class="mb-3 mt-3">
      <label for="dob">Date of Birth</label>
      <input type="date" class="form-control" id="dob" placeholder="Enter date of Birth" name="dob">
    </div>
    <div class="mb-3 mt-3">
      <label for="address">Address</label>
      <input type="text" class="form-control" id="address" placeholder="Enter Address" name="address">
    </div>

    <div class="mb-3 mt-3">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
    <div class="mb-3">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
    </div>
    
    <div class="d-grid">
    <button type="submit" class="btn btn-success btn-block">Submit</button>
     </div>
</form>

  </div>
</div>
</body>
</html>