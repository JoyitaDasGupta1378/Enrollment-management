<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "6th_web_dev";  // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['course_ids'])) {
        // Assume a user is logged in; replace with actual user name logic
        $email= $_SESSION['email'];
        
        

            // Initialize an array to hold success messages
            $success_messages = [];




        // Loop through selected courses
        foreach ($_POST['course_ids'] as $course_id) {
            // Fetch the course name based on course_id
            $course_sql = "SELECT course_name FROM courses WHERE course_id = $course_id";
            $course_result = $conn->query($course_sql);
            $course_row = $course_result->fetch_assoc();
            $course_name = $course_row['course_name'];

            // Insert the selected course and user name into the enrollment table
            $insert_sql = "INSERT INTO enroll (email, course_id, course_name)
                           VALUES ('$email', $course_id, '$course_name')";

            if ($conn->query($insert_sql) === TRUE) {
                $success_messages[] = "Enrollment successful for course: $course_name";
            } else {
                echo "Error: " . $insert_sql . "<br>" . $conn->error;
            }
        }

       // Store the success messages in session
       $_SESSION['success_message'] = implode("<br>", $success_messages);


       // Redirect to the enroll_form.php to display the success message
        header('Location: enroll_backend.php');
        exit;




    } else {
        echo "No courses selected.";
    }
}

// Close connection
$conn->close();
?>
