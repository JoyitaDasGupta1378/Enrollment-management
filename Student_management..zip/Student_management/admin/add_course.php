<?php
session_start();
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Add Courses</title>
    
</head>
<body>
<div class="container mt-4">
  <?php
  if(isset($_SESSION['status']))
  {

    ?>
    
      <div class="alert alert-success alert-dismissible">
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        <strong>Success!</strong><?php
         echo $_SESSION['status'];?> 
      </div>


    <?php
    unset($_SESSION['status']);
  }
  ?>
  <h2>Add Courses</h2>
  <div class="row col-6 ">
  <form action="add_conn.php" method="POST" >
  <div class="mb-3 mt-3">
      <label for="course_id">Course ID</label>
      <input type="text" class="form-control" id="course_id" placeholder="Enter Course ID" name="course_id">
    </div>
    <div class="mb-3 mt-3">
      <label for="course_name">Course Name</label>
      <input type="text" class="form-control" id="course_name" placeholder="Enter Course Name" name="course_name">
    </div>
   
    
    <div class="d-grid">
    <button type="submit" class="btn btn-success btn-block">Submit</button>
     </div>
</form>

  </div>
</div>
</body>
</html>