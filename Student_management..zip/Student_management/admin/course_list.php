<!DOCTYPE html>
<html lang="en">
<head>
  <title>Courses list</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
<div class="d-grid gap-2 d-md-flex justify-content-md-end"> 
  <a href="add_course.php" class="btn btn-primary" type="button">Add Course</a>
</div>
<br>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Course ID</th>
        <th>Course Name</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $conn=mysqli_connect('localhost','root','','6th_web_dev');
   

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql="SELECT * FROM courses";
    $result=$conn->query($sql);
    if($result->num_rows>0){
        while($row=$result->fetch_assoc()){
            echo "<tr>";
            echo "<td>".$row["id"]."</td>";
            echo "<td>".$row["course_id"]."</td>";
            echo "<td>".$row["course_name"]."</td>";
           
            echo "</tr>";
        }
    }
    else{
        echo "<tr><td colspan='3'>No data found</td></tr>";
    }
 
    ?>

    </tbody>
  </table>
</div>

</body>
</html>
