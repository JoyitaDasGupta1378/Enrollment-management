<?php
 session_start();
 $conn=mysqli_connect('localhost','root','','6th_web_dev');
 $course_id= $_POST['course_id'];
 $course_name=$_POST['course_name'];

$sql="INSERT INTO courses (course_id,course_name) VALUES ('$course_id','$course_name') ";
$check= mysqli_query($conn,$sql);
if ($check)
{
    $_SESSION['status']="Course added successfully";
    header('location:add_course.php');

}
else {
    echo "Failed";
}


?>